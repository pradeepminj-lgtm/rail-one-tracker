# Android build notes

The Android project is generated locally by Capacitor; it is not included in this source archive.

1. Install Android Studio and a current Node.js LTS release.
2. Run `npm install`.
3. Run `npm run android:init` once.
4. Set `window.RAIL_API_BASE` in `public/config.js` to your deployed HTTPS API server.
5. Run `npm run android:sync`.
6. Run `npm run android:open`, then use Android Studio to build a debug APK or signed release AAB.

The API key belongs only on the backend server. Never embed it in the Android app.
